﻿namespace DEM2Contour
{
	partial class MainForm
	{
		/// <summary>
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows 窗体设计器生成的代码

		/// <summary>
		/// 设计器支持所需的方法 - 不要
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
			System.Windows.Forms.GroupBox groupBox1;
			System.Windows.Forms.GroupBox groupBox2;
			System.Windows.Forms.Label label1;
			this.pictureBox_initialData = new System.Windows.Forms.PictureBox();
			this.contextMenuStrip_Save = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.ToolStripMenuItem_SavePicture = new System.Windows.Forms.ToolStripMenuItem();
			this.pictureBox_InterpolationData = new System.Windows.Forms.PictureBox();
			this.label_initialData = new System.Windows.Forms.Label();
			this.label_InterpolationData = new System.Windows.Forms.Label();
			this.button_LoadDEMData = new System.Windows.Forms.Button();
			this.button_ChoosePoints = new System.Windows.Forms.Button();
			this.button_SavePointsData = new System.Windows.Forms.Button();
			this.button_Interpolation = new System.Windows.Forms.Button();
			this.button_SaveInterpolation = new System.Windows.Forms.Button();
			this.button_DrawContour = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.textBox_Interval = new System.Windows.Forms.TextBox();
			this.progressBar_Deal = new System.Windows.Forms.ProgressBar();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label_Data = new System.Windows.Forms.Label();
			tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			groupBox1 = new System.Windows.Forms.GroupBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			label1 = new System.Windows.Forms.Label();
			tableLayoutPanel1.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_initialData)).BeginInit();
			this.contextMenuStrip_Save.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_InterpolationData)).BeginInit();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// tableLayoutPanel1
			// 
			tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			tableLayoutPanel1.ColumnCount = 2;
			tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			tableLayoutPanel1.Controls.Add(groupBox1, 0, 0);
			tableLayoutPanel1.Controls.Add(groupBox2, 1, 0);
			tableLayoutPanel1.Controls.Add(this.label_initialData, 0, 1);
			tableLayoutPanel1.Controls.Add(this.label_InterpolationData, 1, 1);
			tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
			tableLayoutPanel1.Name = "tableLayoutPanel1";
			tableLayoutPanel1.RowCount = 2;
			tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
			tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 364F));
			tableLayoutPanel1.Size = new System.Drawing.Size(568, 399);
			tableLayoutPanel1.TabIndex = 11;
			// 
			// groupBox1
			// 
			groupBox1.Controls.Add(this.pictureBox_initialData);
			groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			groupBox1.Location = new System.Drawing.Point(3, 3);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new System.Drawing.Size(278, 364);
			groupBox1.TabIndex = 1;
			groupBox1.TabStop = false;
			groupBox1.Text = "原始数据";
			// 
			// pictureBox_initialData
			// 
			this.pictureBox_initialData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox_initialData.ContextMenuStrip = this.contextMenuStrip_Save;
			this.pictureBox_initialData.Cursor = System.Windows.Forms.Cursors.Default;
			this.pictureBox_initialData.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pictureBox_initialData.Location = new System.Drawing.Point(3, 17);
			this.pictureBox_initialData.Name = "pictureBox_initialData";
			this.pictureBox_initialData.Size = new System.Drawing.Size(272, 344);
			this.pictureBox_initialData.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox_initialData.TabIndex = 0;
			this.pictureBox_initialData.TabStop = false;
			// 
			// contextMenuStrip_Save
			// 
			this.contextMenuStrip_Save.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_SavePicture});
			this.contextMenuStrip_Save.Name = "contextMenuStrip_Save";
			this.contextMenuStrip_Save.Size = new System.Drawing.Size(125, 26);
			// 
			// ToolStripMenuItem_SavePicture
			// 
			this.ToolStripMenuItem_SavePicture.Name = "ToolStripMenuItem_SavePicture";
			this.ToolStripMenuItem_SavePicture.Size = new System.Drawing.Size(124, 22);
			this.ToolStripMenuItem_SavePicture.Text = "保存图像";
			this.ToolStripMenuItem_SavePicture.Click += new System.EventHandler(this.ToolStripMenuItem_SavePicture_Click);
			// 
			// groupBox2
			// 
			groupBox2.Controls.Add(this.pictureBox_InterpolationData);
			groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
			groupBox2.Location = new System.Drawing.Point(287, 3);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(278, 364);
			groupBox2.TabIndex = 2;
			groupBox2.TabStop = false;
			groupBox2.Text = "插值结果";
			// 
			// pictureBox_InterpolationData
			// 
			this.pictureBox_InterpolationData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox_InterpolationData.ContextMenuStrip = this.contextMenuStrip_Save;
			this.pictureBox_InterpolationData.Cursor = System.Windows.Forms.Cursors.Cross;
			this.pictureBox_InterpolationData.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pictureBox_InterpolationData.Location = new System.Drawing.Point(3, 17);
			this.pictureBox_InterpolationData.Name = "pictureBox_InterpolationData";
			this.pictureBox_InterpolationData.Size = new System.Drawing.Size(272, 344);
			this.pictureBox_InterpolationData.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox_InterpolationData.TabIndex = 0;
			this.pictureBox_InterpolationData.TabStop = false;
			this.pictureBox_InterpolationData.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox_InterpolationData_MouseMove);
			// 
			// label_initialData
			// 
			this.label_initialData.AutoSize = true;
			this.label_initialData.Location = new System.Drawing.Point(3, 370);
			this.label_initialData.Name = "label_initialData";
			this.label_initialData.Size = new System.Drawing.Size(59, 24);
			this.label_initialData.TabIndex = 3;
			this.label_initialData.Text = "最高值：0\r\n最低值：0";
			// 
			// label_InterpolationData
			// 
			this.label_InterpolationData.AutoSize = true;
			this.label_InterpolationData.Location = new System.Drawing.Point(287, 370);
			this.label_InterpolationData.Name = "label_InterpolationData";
			this.label_InterpolationData.Size = new System.Drawing.Size(59, 24);
			this.label_InterpolationData.TabIndex = 4;
			this.label_InterpolationData.Text = "最高值：0\r\n最低值：0";
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(10, 247);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(77, 12);
			label1.TabIndex = 8;
			label1.Text = "等高线间隔：";
			// 
			// button_LoadDEMData
			// 
			this.button_LoadDEMData.Location = new System.Drawing.Point(12, 12);
			this.button_LoadDEMData.Name = "button_LoadDEMData";
			this.button_LoadDEMData.Size = new System.Drawing.Size(117, 23);
			this.button_LoadDEMData.TabIndex = 1;
			this.button_LoadDEMData.Text = "加载DEM数据";
			this.button_LoadDEMData.UseVisualStyleBackColor = true;
			this.button_LoadDEMData.Click += new System.EventHandler(this.button_LoadDEMData_Click);
			// 
			// button_ChoosePoints
			// 
			this.button_ChoosePoints.Enabled = false;
			this.button_ChoosePoints.Location = new System.Drawing.Point(12, 70);
			this.button_ChoosePoints.Name = "button_ChoosePoints";
			this.button_ChoosePoints.Size = new System.Drawing.Size(117, 23);
			this.button_ChoosePoints.TabIndex = 2;
			this.button_ChoosePoints.Text = "选取随机点";
			this.button_ChoosePoints.UseVisualStyleBackColor = true;
			this.button_ChoosePoints.Click += new System.EventHandler(this.button_ChoosePoints_Click);
			// 
			// button_SavePointsData
			// 
			this.button_SavePointsData.Enabled = false;
			this.button_SavePointsData.Location = new System.Drawing.Point(12, 99);
			this.button_SavePointsData.Name = "button_SavePointsData";
			this.button_SavePointsData.Size = new System.Drawing.Size(117, 23);
			this.button_SavePointsData.TabIndex = 4;
			this.button_SavePointsData.Text = "导出随机点数据";
			this.button_SavePointsData.UseVisualStyleBackColor = true;
			this.button_SavePointsData.Click += new System.EventHandler(this.button_SavePointsData_Click);
			// 
			// button_Interpolation
			// 
			this.button_Interpolation.Enabled = false;
			this.button_Interpolation.Location = new System.Drawing.Point(12, 157);
			this.button_Interpolation.Name = "button_Interpolation";
			this.button_Interpolation.Size = new System.Drawing.Size(117, 23);
			this.button_Interpolation.TabIndex = 5;
			this.button_Interpolation.Text = "内插数据";
			this.button_Interpolation.UseVisualStyleBackColor = true;
			this.button_Interpolation.Click += new System.EventHandler(this.button_Interpolation_Click);
			// 
			// button_SaveInterpolation
			// 
			this.button_SaveInterpolation.Enabled = false;
			this.button_SaveInterpolation.Location = new System.Drawing.Point(12, 186);
			this.button_SaveInterpolation.Name = "button_SaveInterpolation";
			this.button_SaveInterpolation.Size = new System.Drawing.Size(117, 23);
			this.button_SaveInterpolation.TabIndex = 6;
			this.button_SaveInterpolation.Text = "导出内插后数据";
			this.button_SaveInterpolation.UseVisualStyleBackColor = true;
			this.button_SaveInterpolation.Click += new System.EventHandler(this.button_SaveInterpolation_Click);
			// 
			// button_DrawContour
			// 
			this.button_DrawContour.Enabled = false;
			this.button_DrawContour.Location = new System.Drawing.Point(12, 271);
			this.button_DrawContour.Name = "button_DrawContour";
			this.button_DrawContour.Size = new System.Drawing.Size(117, 23);
			this.button_DrawContour.TabIndex = 7;
			this.button_DrawContour.Text = "绘制等高线";
			this.button_DrawContour.UseVisualStyleBackColor = true;
			this.button_DrawContour.Click += new System.EventHandler(this.button_DrawContour_Click);
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.Controls.Add(this.textBox_Interval);
			this.panel1.Controls.Add(label1);
			this.panel1.Controls.Add(this.button_LoadDEMData);
			this.panel1.Controls.Add(this.button_ChoosePoints);
			this.panel1.Controls.Add(this.button_SavePointsData);
			this.panel1.Controls.Add(this.button_DrawContour);
			this.panel1.Controls.Add(this.button_Interpolation);
			this.panel1.Controls.Add(this.button_SaveInterpolation);
			this.panel1.Location = new System.Drawing.Point(586, 12);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(135, 302);
			this.panel1.TabIndex = 10;
			// 
			// textBox_Interval
			// 
			this.textBox_Interval.Enabled = false;
			this.textBox_Interval.Location = new System.Drawing.Point(82, 244);
			this.textBox_Interval.Name = "textBox_Interval";
			this.textBox_Interval.Size = new System.Drawing.Size(47, 21);
			this.textBox_Interval.TabIndex = 9;
			this.textBox_Interval.Text = "100";
			// 
			// progressBar_Deal
			// 
			this.progressBar_Deal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.progressBar_Deal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
			this.progressBar_Deal.Location = new System.Drawing.Point(3, 5);
			this.progressBar_Deal.Name = "progressBar_Deal";
			this.progressBar_Deal.Size = new System.Drawing.Size(565, 26);
			this.progressBar_Deal.TabIndex = 12;
			// 
			// panel2
			// 
			this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel2.Controls.Add(this.label_Data);
			this.panel2.Controls.Add(this.progressBar_Deal);
			this.panel2.Location = new System.Drawing.Point(12, 417);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(709, 34);
			this.panel2.TabIndex = 13;
			// 
			// label_Data
			// 
			this.label_Data.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label_Data.AutoSize = true;
			this.label_Data.Location = new System.Drawing.Point(572, 5);
			this.label_Data.Name = "label_Data";
			this.label_Data.Size = new System.Drawing.Size(77, 24);
			this.label_Data.TabIndex = 14;
			this.label_Data.Text = "原始值：0.00\r\n计算值：0.00";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(733, 452);
			this.Controls.Add(this.panel2);
			this.Controls.Add(tableLayoutPanel1);
			this.Controls.Add(this.panel1);
			this.MinimumSize = new System.Drawing.Size(746, 399);
			this.Name = "MainForm";
			this.Text = "空间插值及等高线计算";
			tableLayoutPanel1.ResumeLayout(false);
			tableLayoutPanel1.PerformLayout();
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_initialData)).EndInit();
			this.contextMenuStrip_Save.ResumeLayout(false);
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_InterpolationData)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox_initialData;
		private System.Windows.Forms.Button button_LoadDEMData;
		private System.Windows.Forms.Button button_ChoosePoints;
		private System.Windows.Forms.Button button_SavePointsData;
		private System.Windows.Forms.Button button_Interpolation;
		private System.Windows.Forms.Button button_SaveInterpolation;
		private System.Windows.Forms.Button button_DrawContour;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.PictureBox pictureBox_InterpolationData;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip_Save;
		private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_SavePicture;
		private System.Windows.Forms.Label label_initialData;
		private System.Windows.Forms.Label label_InterpolationData;
		private System.Windows.Forms.TextBox textBox_Interval;
		private System.Windows.Forms.ProgressBar progressBar_Deal;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label_Data;
	}
}

