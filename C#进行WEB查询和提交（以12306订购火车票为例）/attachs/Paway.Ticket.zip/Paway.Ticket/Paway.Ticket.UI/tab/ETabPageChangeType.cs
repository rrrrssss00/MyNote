﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Paway.Ticket.UI
{
    public enum ETabPageChangeType
    {
        Added,
        Removed,
        Changed,
        SelectionChanged
    }
}
