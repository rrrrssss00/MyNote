﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Paway.Ticket.UI
{
    public enum ETabPageAlignment
    {
        Top,
        Bottom,
        Left,
        Right
    }
}
