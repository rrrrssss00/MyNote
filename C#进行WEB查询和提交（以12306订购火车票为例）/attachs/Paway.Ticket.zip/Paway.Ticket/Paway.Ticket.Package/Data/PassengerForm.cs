﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Paway.Ticket.Package.Data
{
    [Serializable]
    public class PassengerForm
    {
        public QueryLeftNewDetail queryLeftNewDetailDTO { get; set; }
    }
}
